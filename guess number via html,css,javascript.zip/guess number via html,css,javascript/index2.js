let arr=[1,2,3];

 arr=[...arr,1];
console.log(arr);
let a=document.querySelector(".spread");
a.innerHTML=arr;